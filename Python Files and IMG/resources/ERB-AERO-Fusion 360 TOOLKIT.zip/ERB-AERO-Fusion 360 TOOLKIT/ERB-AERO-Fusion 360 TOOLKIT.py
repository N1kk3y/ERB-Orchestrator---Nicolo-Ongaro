import adsk.core, adsk.fusion, adsk.cam, traceback
import os

handlers = []
interpolated_points = []  # Lista globale: ogni elemento è {'entity': entity, 'points': [...]}

# ============================================================
# Run / Stop
# ============================================================

def run(context):
    ui = None
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface

        # -------------------------------
        # Tool 1: Crea punti interpolati
        # -------------------------------
        cmd_def1 = ui.commandDefinitions.itemById('SketchPointsAddin')
        if not cmd_def1:
            cmd_def1 = ui.commandDefinitions.addButtonDefinition(
                'SketchPointsAddin',
                'Crea Punti Interpolati',
                'Seleziona una linea o spline nello sketch e crea punti interpolati'
            )

        # -------------------------------
        # Tool 2: Esporta punti interpolati
        # -------------------------------
        cmd_def2 = ui.commandDefinitions.itemById('ExportInterpolatedPoints')
        if not cmd_def2:
            cmd_def2 = ui.commandDefinitions.addButtonDefinition(
                'ExportInterpolatedPoints',
                'Esporta Punti Interpolati',
                'Esporta le coordinate dei punti interpolati in un file .txt'
            )

        # Aggiungi al pannello Utilities
        tools_tab = ui.allToolbarTabs.itemById('ToolsTab')
        panel = tools_tab.toolbarPanels.itemById('UtilitiesPanel') if tools_tab else None
        if not panel:
            panel = ui.allToolbarPanels.itemById('SolidScriptsAddinsPanel')

        if panel:
            if not panel.controls.itemById('SketchPointsAddin'):
                panel.controls.addCommand(cmd_def1)
            if not panel.controls.itemById('ExportInterpolatedPoints'):
                panel.controls.addCommand(cmd_def2)

        # Handlers
        on_created1 = CommandCreatedHandler()
        cmd_def1.commandCreated.add(on_created1)
        handlers.append(on_created1)

        on_created2 = ExportPointsCommandCreatedHandler()
        cmd_def2.commandCreated.add(on_created2)
        handlers.append(on_created2)

    except:
        if ui:
            ui.messageBox('Errore run():\n{}'.format(traceback.format_exc()))

def stop(context):
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface
        panel = ui.allToolbarPanels.itemById('UtilitiesPanel') or \
                ui.allToolbarPanels.itemById('SolidScriptsAddinsPanel')
        if panel:
            ctrl1 = panel.controls.itemById('SketchPointsAddin')
            if ctrl1:
                ctrl1.deleteMe()
            ctrl2 = panel.controls.itemById('ExportInterpolatedPoints')
            if ctrl2:
                ctrl2.deleteMe()
        cmd_def1 = ui.commandDefinitions.itemById('SketchPointsAddin')
        if cmd_def1:
            cmd_def1.deleteMe()
        cmd_def2 = ui.commandDefinitions.itemById('ExportInterpolatedPoints')
        if cmd_def2:
            cmd_def2.deleteMe()
        interpolated_points.clear()
    except:
        if ui:
            ui.messageBox('Errore stop():\n{}'.format(traceback.format_exc()))

# ============================================================
# Tool 1: Crea punti interpolati
# ============================================================

class CommandCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            cmd = args.command
            cmd.commandInputs.addIntegerSpinnerCommandInput(
                'numPoints', 'Numero punti', 2, 1000, 1, 5
            )
            sel_input = cmd.commandInputs.addSelectionInput(
                'selEntity', 'Seleziona entità', 'Seleziona una linea o spline nello sketch'
            )
            sel_input.addSelectionFilter('SketchCurves')
            sel_input.setSelectionLimits(1, 1)

            on_execute = CommandExecuteHandler()
            cmd.execute.add(on_execute)
            handlers.append(on_execute)

        except:
            adsk.core.Application.get().userInterface.messageBox(
                'Errore CommandCreatedHandler:\n{}'.format(traceback.format_exc())
            )

class CommandExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        global interpolated_points
        try:
            cmd = args.firingEvent.sender
            app = adsk.core.Application.get()
            ui = app.userInterface
            product = app.activeProduct
            design = adsk.fusion.Design.cast(product)

            num_input = cmd.commandInputs.itemById('numPoints')
            N = num_input.value
            if N < 2:
                ui.messageBox("Il numero di punti deve essere almeno 2")
                return

            sel_input = cmd.commandInputs.itemById('selEntity')
            if not sel_input or sel_input.selectionCount == 0:
                ui.messageBox("Seleziona prima una linea o spline nello sketch.")
                return
            sel = sel_input.selection(0)
            entity = sel.entity
            sketch = adsk.fusion.Sketch.cast(entity.parentSketch)
            if sketch is None:
                ui.messageBox("Errore: impossibile determinare lo sketch")
                return

            points = create_points_on_sketch_entity(sketch, entity, N)
            if points:
                interpolated_points.append({'entity': entity, 'points': points})
                ui.messageBox(f"{N} punti creati su entità selezionata.")

        except:
            adsk.core.Application.get().userInterface.messageBox(
                'Errore CommandExecuteHandler:\n{}'.format(traceback.format_exc())
            )

def create_points_on_sketch_entity(sketch, entity, N):
    points_created = []
    geom = entity.geometry
    if geom.objectType == adsk.core.Line3D.classType():
        start = geom.startPoint
        end = geom.endPoint
        for i in range(N):
            t = i / (N - 1)
            pt3d = adsk.core.Point3D.create(
                start.x + t * (end.x - start.x),
                start.y + t * (end.y - start.y),
                start.z + t * (end.z - start.z)
            )
            sk_pt = sketch.sketchPoints.add(pt3d)
            points_created.append(sk_pt)
    elif geom.objectType == adsk.core.NurbsCurve3D.classType():
        evaluator = geom.evaluator
        for i in range(N):
            t = i / (N - 1)
            success, pt3d = evaluator.getPointAtParameter(t)
            if success:
                sk_pt = sketch.sketchPoints.add(pt3d)
                points_created.append(sk_pt)
    return points_created

# ============================================================
# Tool 2: Esporta punti interpolati
# ============================================================

class ExportPointsCommandCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            cmd = args.command
            on_execute = ExportPointsExecuteHandler()
            cmd.execute.add(on_execute)
            handlers.append(on_execute)
        except:
            adsk.core.Application.get().userInterface.messageBox(
                'Errore ExportPointsCommandCreatedHandler:\n{}'.format(traceback.format_exc())
            )

class ExportPointsExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        global interpolated_points
        try:
            app = adsk.core.Application.get()
            ui = app.userInterface

            if not interpolated_points:
                ui.messageBox("Non ci sono punti interpolati da esportare.")
                return

            # Dialog per salvare file
            fileDlg = ui.createFileDialog()
            fileDlg.isMultiSelectEnabled = False
            fileDlg.title = 'Salva file punti interpolati'
            fileDlg.filter = 'Testo (*.txt)'
            dlgResult = fileDlg.showSave()
            if dlgResult != adsk.core.DialogResults.DialogOK:
                return
            filename = fileDlg.filename

            # Concatenazione punti con prima spline invertita
            all_points = []

            for idx, group in enumerate(interpolated_points):
                pts = group['points']
                if idx == 0:  # Prima spline
                    pts = list(reversed(pts))
                all_points.extend(pts)

            # Scrive tutto nel file
            with open(filename, 'w') as f:
                for pt in all_points:
                    g = pt.geometry
                    f.write(f"{g.x},{g.y},{g.z}\n")

            ui.messageBox(f"{len(interpolated_points)} entità esportate in:\n{filename}")

        except:
            adsk.core.Application.get().userInterface.messageBox(
                'Errore ExportPointsExecuteHandler:\n{}'.format(traceback.format_exc())
            )